// Global variables
let allData = null;
let myChart = null;
let currentChartData = null;
let initialLoad = true;

// Helper function to get the Plotly chart instance
function getPlotlyChart() {
    const div = document.getElementById('plotlyChart');
    if (!div) {
        console.error('Cannot find plotlyChart div');
        return null;
    }
    
    // Return the div element - Plotly functions expect this
    return div;
}

// Load data and render chart when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Add loading message
    showLoading(true, 'Loading Chickpeas spot price data...');
    
    loadData();
    
    // Add event listeners for controls
    document.getElementById('timeRange').addEventListener('change', updateChartTimeRange);
    document.getElementById('chartType').addEventListener('change', updateChartType);
    document.getElementById('indicatorType').addEventListener('change', updateIndicators);
    document.getElementById('showSMA').addEventListener('change', updateIndicatorVisibility);
    document.getElementById('showBollingerBands').addEventListener('change', updateIndicatorVisibility);
    
    // Add window resize handler to resize the chart
    window.addEventListener('resize', function() {
        const chart = getPlotlyChart();
        if (chart) {
            Plotly.Plots.resize(chart);
        }
    });
});

// Load data from API
async function loadData() {
    try {
        showLoading(true, 'Fetching data...');
        
        // First get the raw data from our API
        const response = await fetch('/data');
        
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        
        allData = await response.json();
        
        if (allData.error) {
            throw new Error(allData.error);
        }
        
        console.log('Data loaded successfully');
        
        // Now fetch the plotly figure and display it
        showLoading(true, 'Generating chart...');
        initialLoad = true;
        await loadPlotlyChart();
        initialLoad = false;
        
        showLoading(false);
    } catch (error) {
        console.error('Error loading data:', error);
        showError(error.message);
        showLoading(false);
    }
}

// Load Plotly chart
async function loadPlotlyChart() {
    try {
        // Get the selected indicator type or default to 'none'
        const indicatorType = document.getElementById('indicatorType').value;
        const chartType = document.getElementById('chartType').value;
        
        console.log('Loading chart with type:', chartType, 'and indicators:', indicatorType);
        
        // Build the URL with the indicator choice and chart type
        // Ensure we have consistent indicator values (none if nothing selected)
        const url = `/plot?indicators=${indicatorType || 'none'}&chart_type=${chartType}`;
        console.log('Request URL:', url);
        
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        
        const plotData = await response.json();
        console.log('Received plot data:', plotData);
        
        // Check if we received valid data
        if (!plotData || !plotData.data || !plotData.layout) {
            console.error("Invalid data received from server:", plotData);
            showError("Invalid data received from server. Please try refreshing the page.");
            showLoading(false);
            return;
        }
        
        // Check if data array is empty
        console.log('Plot data traces count:', plotData.data.length);
        if (plotData.data.length === 0) {
            console.error("Empty data array received from server");
            showError("No chart data available. Please try selecting different options.");
            showLoading(false);
            return;
        }
        
        currentChartData = plotData;
        
        // Create the plot with animation
        const layout = plotData.layout;
        
        // Add animation settings for transitions
        layout.transition = {
            duration: initialLoad ? 0 : 500,
            easing: 'cubic-in-out'
        };
        
        // Set the x-axis type to date to ensure proper date handling
        if (!layout.xaxis) {
            layout.xaxis = {};
        }
        layout.xaxis.type = 'date';
        
        // Set rangeslider visibility based on chart type
        layout.xaxis.rangeslider = {
            visible: chartType === 'candlestick' ? true : false
        };
        
        // Set default date range from Jan 2024 to current date
        if (allData && allData.date) {
            const dates = allData.date.map(d => new Date(d));
            const jan2024 = new Date('2024-01-01');
            
            // Find the index closest to Jan 2024
            let startIndex = 0;
            for (let i = 0; i < dates.length; i++) {
                if (dates[i] >= jan2024) {
                    startIndex = i;
                    break;
                }
            }
            
            // Set the default range
            if (layout.xaxis) {
                layout.xaxis.range = [
                    dates[startIndex] || dates[0],  // Use Jan 2024 or first date if not found
                    dates[dates.length - 1]        // Latest date
                ];
                console.log(`Setting initial date range: ${layout.xaxis.range[0]} to ${layout.xaxis.range[1]}`);
            }
            
            // Update the time range selector to match
            document.getElementById('timeRange').value = 'custom';
        }
        
        // Get the Plotly div element or create it if needed
        const plotlyDiv = document.getElementById('plotlyChart');
        if (!plotlyDiv) {
            console.error('Plot container not found');
            showError("Cannot find plot container element");
            showLoading(false);
            return;
        }
        
        // Clear any existing chart to avoid conflicts
        try {
            Plotly.purge(plotlyDiv);
        } catch (e) {
            console.log('No existing chart to purge');
        }
        
        // Create the plot
        await Plotly.newPlot(plotlyDiv, plotData.data, layout, {
            responsive: true,
            displayModeBar: true,
            displaylogo: false,
            modeBarButtonsToRemove: [
                'lasso2d', 
                'select2d',
                'toggleSpikelines'
            ],
            toImageButtonOptions: {
                format: 'png',
                filename: 'chickpeas_spot_price_chart',
                height: 800,
                width: 1200,
                scale: 2
            }
        });
        
        console.log('Chart created successfully');
        
        // Store reference to the chart
        myChart = plotlyDiv;
        
        // Add click event for chart points
        myChart.on('plotly_click', function(data) {
            const point = data.points[0];
            const dateStr = new Date(point.x).toLocaleDateString();
            
            let valueHTML = '';
            if (point.data.type === 'candlestick') {
                valueHTML = `
                    <div>Open: ${point.open.toFixed(2)}</div>
                    <div>High: ${point.high.toFixed(2)}</div>
                    <div>Low: ${point.low.toFixed(2)}</div>
                    <div>Close: ${point.close.toFixed(2)}</div>
                `;
            } else {
                valueHTML = `<div>Price: ${point.y.toFixed(2)}</div>`;
            }
            
            // Create a tooltip
            const tooltipHTML = `
                <div style="padding: 10px; background: #fff; border-radius: 5px; box-shadow: 0 2px 10px rgba(0,0,0,0.2);">
                    <div style="font-weight: bold; margin-bottom: 5px;">Date: ${dateStr}</div>
                    ${valueHTML}
                </div>
            `;
            
            // Show temporary notification
            showNotification(tooltipHTML, 2000);
        });
        
        // Update visibility of indicators based on checkboxes
        updateIndicatorVisibility();
        
        // Hide the loading indicator after everything is done
        showLoading(false);
    } catch (error) {
        console.error('Error loading chart:', error);
        showLoading(false);
        showError("Failed to load chart: " + error.message);
    }
}

// Show notification
function showNotification(html, duration) {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('chartNotification');
    if (!notification) {
        notification = document.createElement('div');
        notification.id = 'chartNotification';
        notification.style.position = 'fixed';
        notification.style.bottom = '20px';
        notification.style.right = '20px';
        notification.style.zIndex = '1000';
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.3s ease';
        document.body.appendChild(notification);
    }
    
    // Set content and show
    notification.innerHTML = html;
    notification.style.opacity = '1';
    
    // Hide after duration
    setTimeout(() => {
        notification.style.opacity = '0';
    }, duration);
}

// Update chart based on indicators selection
async function updateIndicators() {
    try {
        showLoading(true, 'Updating indicators...');
        await loadPlotlyChart();
        
        // Ensure loading is hidden
        setTimeout(() => {
            showLoading(false);
        }, 500);
    } catch (error) {
        console.error('Error updating indicators:', error);
        showLoading(false);
    }
}

// Update visibility of indicators based on toggle switches
function updateIndicatorVisibility() {
    const chart = getPlotlyChart();
    if (!chart) return;
    
    try {
        const showSMA = document.getElementById('showSMA').checked;
        const showBB = document.getElementById('showBollingerBands').checked;
        
        // Loop through all traces and update their visibility
        const plotlyData = chart.data;
        if (!plotlyData || !plotlyData.length) {
            console.warn('No plot data available for updating visibility');
            return;
        }
        
        // Store traces that need updating
        const updatedIndices = [];
        const updatedVisibility = [];
        
        for (let i = 0; i < plotlyData.length; i++) {
            const trace = plotlyData[i];
            let updated = false;
            
            // Handle SMA visibility
            if (trace.name === 'SMA 20' || trace.name === 'SMA 50') {
                updatedIndices.push(i);
                updatedVisibility.push(showSMA);
                updated = true;
            }
            // Handle Bollinger Bands visibility (including the dummy legend entry)
            else if (trace.name === 'BB Upper' || trace.name === 'BB Lower' || trace.name === 'Bollinger Bands') {
                updatedIndices.push(i);
                updatedVisibility.push(showBB);
                updated = true;
            }
        }
        
        // Only update if we have changes to make
        if (updatedIndices.length > 0) {
            console.log('Updating indicator visibility:', 
                        'SMA:', showSMA, 
                        'Bollinger:', showBB);
            
            // Update all traces with one call
            Plotly.restyle(chart, 'visible', updatedVisibility, updatedIndices);
        }
    } catch (error) {
        console.error('Exception in updateIndicatorVisibility:', error);
    }
}

// Update chart based on selected time range
async function updateChartTimeRange() {
    // Make sure we have data
    if (!allData) {
        console.error('Cannot update time range: allData is not available');
        return;
    }
    
    // Get the chart element
    const plotlyDiv = getPlotlyChart();
    if (!plotlyDiv) {
        console.error('Cannot update time range: chart not available');
        return;
    }
    
    try {
        console.log('Starting to update time range');
        showLoading(true, 'Updating time range...');
        
        const timeRange = document.getElementById('timeRange').value;
        console.log('Selected time range:', timeRange);
        
        // Get date strings from allData and convert to Date objects
        if (!allData.date || !Array.isArray(allData.date)) {
            console.error('Date data is missing or invalid:', allData.date);
            showLoading(false);
            return;
        }
        
        // Convert string dates to Date objects
        const dates = allData.date.map(d => new Date(d));
        
        // Calculate cutoff date based on selected time range
        const now = new Date();
        let cutoffDate = null;
        
        switch (timeRange) {
            case '1m':
                cutoffDate = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
                break;
            case '3m':
                cutoffDate = new Date(now.getFullYear(), now.getMonth() - 3, now.getDate());
                break;
            case '6m':
                cutoffDate = new Date(now.getFullYear(), now.getMonth() - 6, now.getDate());
                break;
            case '1y':
                cutoffDate = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
                break;
            case 'custom':
                cutoffDate = new Date('2024-01-01');
                break;
            case 'all':
            default:
                cutoffDate = new Date(0); // Beginning of time
                break;
        }
        
        console.log('Cutoff date:', cutoffDate);
        
        // Find the index where data should start
        let minIndex = 0;
        for (let i = 0; i < dates.length; i++) {
            if (dates[i] >= cutoffDate) {
                minIndex = i;
                break;
            }
        }
        
        // Ensure we have at least some data points
        minIndex = Math.max(0, minIndex);
        
        // If there's no data in the selected range, show all data
        if (minIndex >= dates.length - 1) {
            console.warn('No data in selected range, showing all data');
            minIndex = 0;
        }
        
        // Calculate the date range to display
        const startDate = dates[minIndex];
        const endDate = dates[dates.length - 1];
        
        console.log(`Setting range: ${startDate.toISOString()} to ${endDate.toISOString()}`);
        
        // Ensure we have a title to use in the chart
        let title = 'Chickpeas Spot Price';
        
        try {
            // Get Plotly's layout information if available
            const gd = plotlyDiv;
            if (gd && gd._fullLayout && gd._fullLayout.title) {
                if (typeof gd._fullLayout.title === 'object' && gd._fullLayout.title.text) {
                    const currentTitle = gd._fullLayout.title.text;
                    if (currentTitle && currentTitle.includes('(')) {
                        title = currentTitle.split('(')[0].trim();
                    } else if (currentTitle) {
                        title = currentTitle;
                    }
                } else if (typeof gd._fullLayout.title === 'string') {
                    const currentTitle = gd._fullLayout.title;
                    if (currentTitle && currentTitle.includes('(')) {
                        title = currentTitle.split('(')[0].trim();
                    } else if (currentTitle) {
                        title = currentTitle;
                    }
                }
            }
            console.log('Using title:', title);
        } catch (e) {
            console.warn('Error extracting title from layout, using default:', e);
        }
        
        // Create the update object
        const update = {
            'xaxis.range': [startDate, endDate],
            'title.text': `${title} (${getTimeRangeLabel(timeRange)})`
        };
        
        try {
            // Apply the update to the plot
            await Plotly.relayout(plotlyDiv, update);
            console.log('Time range update successful');
        } catch (error) {
            console.error('Error updating time range with Plotly.relayout:', error);
            
            // If the basic update failed, try a more direct approach
            try {
                // Directly set the range using the Plotly.update method
                const xaxis = { range: [startDate, endDate] };
                await Plotly.update(plotlyDiv, {}, { xaxis });
                console.log('Alternative update method worked');
            } catch (err) {
                console.error('Alternative update method also failed:', err);
            }
        }
        
        // Always hide the loading indicator when done
        showLoading(false);
    } catch (error) {
        console.error('Exception in updateChartTimeRange:', error);
        showLoading(false);
    }
}

// Get time range label for chart title
function getTimeRangeLabel(timeRange) {
    switch (timeRange) {
        case '1m': return 'Last Month';
        case '3m': return 'Last 3 Months';
        case '6m': return 'Last 6 Months';
        case '1y': return 'Last Year';
        case 'custom': return 'Jan 2024 - Now';
        case 'all': return 'All Time';
        default: return '';
    }
}

// Show/hide loading indicator
function showLoading(show, message = 'Loading data...') {
    const loadingElement = document.getElementById('loadingIndicator');
    if (!loadingElement) return;
    
    const loadingMessage = loadingElement.querySelector('p');
    
    if (show) {
        loadingMessage.textContent = message;
        loadingElement.style.display = 'flex';
    } else {
        loadingElement.style.display = 'none';
    }
}

// Show error message
function showError(message) {
    const errorContainer = document.getElementById('errorMessage');
    const errorDetails = document.getElementById('errorDetails');
    
    errorDetails.textContent = message || 'An unknown error occurred while loading the data.';
    errorContainer.style.display = 'block';
}

// Update chart type
async function updateChartType() {
    try {
        const chartType = document.getElementById('chartType').value;
        console.log('Updating chart type to:', chartType);
        showLoading(true, 'Updating chart type...');
        
        // Complete reset of the chart to avoid any potential issues
        // with Plotly's internal state when switching chart types
        const plotlyDiv = document.getElementById('plotlyChart');
        
        // Clear any existing chart
        if (plotlyDiv) {
            Plotly.purge(plotlyDiv);
            console.log('Cleared existing chart');
        }
        
        // Reset our chart reference
        myChart = null;
        
        // Force recreation of the chart with the new type
        await loadPlotlyChart();
        
        // Hide loading indicator after chart is updated
        showLoading(false);
    } catch (error) {
        console.error('Error updating chart type:', error);
        showLoading(false);
    }
} 